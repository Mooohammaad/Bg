document.addEventListener('DOMContentLoaded', function() {
    const wallpapers = document.querySelectorAll('.wallpaper');
    const overlay = document.getElementById('overlay');
    const overlayImg = document.getElementById('overlay-img');
    const overlayDownload = document.getElementById('overlay-download');
    const closeOverlay = document.getElementById('close-overlay');

    // تكبير الصورة عند النقر عليها
    wallpapers.forEach(wallpaper => {
        wallpaper.addEventListener('click', function() {
            const imgSrc = this.querySelector('img').src;
            overlayImg.src = imgSrc;
            overlayDownload.href = imgSrc;
            overlay.style.display = 'flex';
        });
    });

    // إغلاق الـ overlay
    closeOverlay.addEventListener('click', function() {
        overlay.style.display = 'none';
    });

    // إغلاق الـ overlay عند النقر خارج الصورة
    overlay.addEventListener('click', function(event) {
        if (event.target === overlay) {
            overlay.style.display = 'none';
        }
    });
});







document.addEventListener('DOMContentLoaded', function() {
    const navWrapper = document.querySelector('.nav-wrapper');
    const nav = navWrapper.querySelector('nav ul');
    let isDragging = false;
    let startPos = 0;
    let currentTranslate = 0;
    let prevTranslate = 0;
    let animationID;

    navWrapper.addEventListener('touchstart', touchStart);
    navWrapper.addEventListener('touchmove', touchMove);
    navWrapper.addEventListener('touchend', touchEnd);
    navWrapper.addEventListener('mousedown', touchStart);
    navWrapper.addEventListener('mousemove', touchMove);
    navWrapper.addEventListener('mouseup', touchEnd);
    navWrapper.addEventListener('mouseleave', touchEnd);

    function touchStart(event) {
        isDragging = true;
        startPos = getPositionX(event);
        animationID = requestAnimationFrame(animation);
        navWrapper.classList.add('grabbing');
    }

    function touchMove(event) {
        if (isDragging) {
            const currentPosition = getPositionX(event);
            currentTranslate = prevTranslate + currentPosition - startPos;
        }
    }

    function touchEnd() {
        cancelAnimationFrame(animationID);
        isDragging = false;
        prevTranslate = currentTranslate;
        navWrapper.classList.remove('grabbing');
    }

    function getPositionX(event) {
        return event.type.includes('mouse') ? event.pageX : event.touches[0].clientX;
    }

    function animation() {
        nav.style.transform = `translateX(${currentTranslate}px)`;
        if (isDragging) requestAnimationFrame(animation);
    }
});



document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.querySelector('.sidebar');
    const toggleButton = document.querySelector('.sidebar-toggle');

    toggleButton.addEventListener('click', function() {
        if (sidebar.style.left === '-250px' || sidebar.style.left === '') {
            sidebar.style.left = '0';
        } else {
            sidebar.style.left = '-250px';
        }
    });
});